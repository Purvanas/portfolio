﻿using System;

namespace AP4_GSB_Mirocha
{
    class Program
    {
        static void Main(string[] args)
        {
            /** Définition des variables ***********************************************/
            string réponse;
            bool argument;
            int stock;
            string medicament;
            string medicament_save;
            bool restock;
            int D;
            int I;
            int E;
            int S;
            int nb_medicament;
            double total;
            double prix_medicament;
            D = 0;
            I = 0;
            E = 0;
            S = 0;
            /** Boucle infini pour que le programme ne se ferme pas ***********************************************/
            while ("infini" == "infini")
            {
                medicament = "null";
                réponse = "null";
                Console.WriteLine("Bonjour veuillez selectioner votre action (AV = ajouter des médicaments en stock) / (VM = vendre des médicaments) / (VS = visualiser le stock de médicament)");
                argument = false;
             /** Boucle de selection des actions (ici "argument" me sert à crer une boucle infini, je le réutilise plusieur fois)***********************/
                while (argument == false)
                {
                    réponse = Console.ReadLine();
                    if (réponse == "AV") argument = true;
                    else if (réponse == "VM") argument = true;
                    else if (réponse == "VS") argument = true;
                    else
                    {
                        Console.WriteLine("vous avez fais une erreur veuillez resaisir votre choix");
                    }
                }

                if (réponse == "AV")
                {
                    argument = false;
                    /** Boucle de selection du médicament ***********************************************/
                    Console.WriteLine("Veuillez selectionner le médicament à remettre en stock (D = Doliprane) / (E = Efferalgant) / (I = Ibuprofene) / (S = Spasfon) ");
                    while (argument == false)
                    {
                        medicament = Console.ReadLine();
                        if (medicament == "D") argument = true;
                        else if (medicament == "I") argument = true;
                        else if (medicament == "E") argument = true;
                        else if (medicament == "S") argument = true;
                        else
                        {
                            Console.WriteLine("vous avez fais une erreur veuillez resaisir votre choix");
                        }
                    }
                    restock = true;
                    /** Boucle du restockage des médicament (cassé par restock = false) ***********************************************/
                    while (restock == true)
                    {
                        if (medicament == "D")
                        {
                            Console.WriteLine("Veuillez selectionner le nombre à remettre en stock");
                            stock = int.Parse(Console.ReadLine());
                            D = D + stock;
                            /** Medicament_save me permetra de faire une comparaison pour ne pas rechoisir le même **********************************/
                            medicament_save = medicament;
                            argument = false;
                            Console.WriteLine("voulez vous ajoutez d'autre médicaments ? (Y/N)");
                            while (argument == false)
                            {
                                réponse = Console.ReadLine();
                                if (réponse == "Y")
                                {
                                    argument = false;
                                    /** Impossibilité de rechoisir le même médicament ***********************************************/
                                    Console.WriteLine("Veuillez choisir un autre médicament (E = Efferalgant) / (I = Ibuprofene) / (S = Spasfon)");
                                    while (medicament_save == medicament || argument == false)
                                    {
                                        medicament = Console.ReadLine();
                                        if (medicament == "I") argument = true;
                                        else if (medicament == "E") argument = true;
                                        else if (medicament == "S") argument = true;
                                        else
                                        {
                                            Console.WriteLine("vous avez fais une erreur veuillez resaisir votre choix");
                                        }
                                    }
                                }
                                else if (réponse == "N")
                                {
                                    argument = true;
                                    restock = false;
                                    Console.WriteLine("Votre stock de médicament est : ");
                                    Console.WriteLine("Doliprane : " + D);
                                    Console.WriteLine("Ibuprofene : " + I);
                                    Console.WriteLine("Efferalgant : " + E);
                                    Console.WriteLine("Spasfon : " + S);
                                }
                                else
                                {
                                    Console.WriteLine("vous avez fais une erreur veuillez resaisir votre choix");
                                }
                            }
                        }
                        if (medicament == "I")
                        {
                            Console.WriteLine("Veuillez selectionner le nombre à remettre en stock");
                            stock = int.Parse(Console.ReadLine());
                            I = I + stock;
                            medicament_save = medicament;
                            argument = false;
                            Console.WriteLine("voulez vous ajoutez d'autre médicaments ? (Y/N)");
                            while (argument == false)
                            {
                                réponse = Console.ReadLine();
                                if (réponse == "Y")
                                {
                                    argument = false;
                                    Console.WriteLine("Veuillez choisir un autre médicament  (D = Doliprane) / (E = Efferalgant) / (S = Spasfon)");
                                    while (medicament_save == medicament || argument == false)
                                    {
                                        medicament = Console.ReadLine();
                                        if (medicament == "D") argument = true;
                                        else if (medicament == "E") argument = true;
                                        else if (medicament == "S") argument = true;
                                        else
                                        {
                                            Console.WriteLine("vous avez fais une erreur veuillez resaisir votre choix");
                                        }
                                    }
                                }
                                else if (réponse == "N")
                                {
                                    argument = true;
                                    restock = false;
                                    Console.WriteLine("Votre stock de médicament est : ");
                                    Console.WriteLine("Doliprane : " + D);
                                    Console.WriteLine("Ibuprofene : " + I);
                                    Console.WriteLine("Efferalgant : " + E);
                                    Console.WriteLine("Spasfon : " + S);
                                }
                                else
                                {
                                    Console.WriteLine("vous avez fais une erreur veuillez resaisir votre choix");
                                }
                            }

                        }
                        if (medicament == "E")
                        {
                            Console.WriteLine("Veuillez selectionner le nombre à remettre en stock");
                            stock = int.Parse(Console.ReadLine());
                            E = E + stock;
                            medicament_save = medicament;
                            argument = false;
                            Console.WriteLine("voulez vous ajoutez d'autre médicaments ? (Y/N)");
                            while (argument == false)
                            {
                                réponse = Console.ReadLine();
                                if (réponse == "Y")
                                {
                                    argument = false;
                                    Console.WriteLine("Veuillez choisir un autre médicament  (D = Doliprane) / (I = Ibuprofene) / (S = Spasfon)");
                                    while (medicament_save == medicament || argument == false)
                                    {
                                        medicament = Console.ReadLine();
                                        if (medicament == "I") argument = true;
                                        else if (medicament == "D") argument = true;
                                        else if (medicament == "S") argument = true;
                                        else
                                        {
                                            Console.WriteLine("vous avez fais une erreur veuillez resaisir votre choix");
                                        }
                                    }
                                }
                                else if (réponse == "N")
                                {
                                    argument = true;
                                    restock = false;
                                    Console.WriteLine("Votre stock de médicament est : ");
                                    Console.WriteLine("Doliprane : " + D);
                                    Console.WriteLine("Ibuprofene : " + I);
                                    Console.WriteLine("Efferalgant : " + E);
                                    Console.WriteLine("Spasfon : " + S);
                                }
                                else
                                {
                                    Console.WriteLine("vous avez fais une erreur veuillez resaisir votre choix");
                                }
                            }
                        }
                        if (medicament == "S")
                        {
                            Console.WriteLine("Veuillez selectionner le nombre à remettre en stock");
                            stock = int.Parse(Console.ReadLine());
                            S = S + stock;
                            medicament_save = medicament;
                            argument = false;
                            Console.WriteLine("voulez vous ajoutez d'autre médicaments ? (Y/N)");
                            while (argument == false)
                            {
                                réponse = Console.ReadLine();
                                if (réponse == "Y")
                                {
                                    argument = false;
                                    Console.WriteLine("Veuillez choisir un autre médicament  (D = Doliprane) / (E = Efferalgant) / (I = Ibuprofene) ");
                                    while (medicament_save == medicament || argument == false)
                                    {
                                        medicament = Console.ReadLine();
                                        if (medicament == "I") argument = true;
                                        else if (medicament == "E") argument = true;
                                        else if (medicament == "D") argument = true;
                                        else
                                        {
                                            Console.WriteLine("vous avez fais une erreur veuillez resaisir votre choix");
                                        }
                                    }
                                }
                                else if (réponse == "N")
                                {
                                    argument = true;
                                    restock = false;
                                    Console.WriteLine("Votre stock de médicament est : ");
                                    Console.WriteLine("Doliprane : " + D);
                                    Console.WriteLine("Ibuprofene : " + I);
                                    Console.WriteLine("Efferalgant : " + E);
                                    Console.WriteLine("Spasfon : " + S);
                                }
                                else
                                {
                                    Console.WriteLine("vous avez fais une erreur veuillez resaisir votre choix");
                                }
                            }
                        }
                    }

                }
                /** Boucle de vente des médicaments ***********************************************/
                if (réponse == "VM")
                {
                    argument = false;
                    Console.WriteLine("Veuillez selectionner le médicament à vendre (D = Doliprane) / (E = Efferalgant) / (I = Ibuprofene) / (S = Spasfon) ");
                    while (argument == false)
                    {
                        medicament = Console.ReadLine();
                        if (medicament == "D") argument = true;
                        else if (medicament == "I") argument = true;
                        else if (medicament == "E") argument = true;
                        else if (medicament == "S") argument = true;
                        else
                        {
                            Console.WriteLine("vous avez fais une erreur veuillez resaisir votre choix");
                        }
                    }
                    Console.WriteLine("Veuillez saisir le nombre de médicament à vendre");
                    nb_medicament = 0;
                    /** Choix du nombre de médicament ***********************************************/
                    if (medicament == "D")
                    {
                        nb_medicament = int.Parse(Console.ReadLine());
                        while (D < nb_medicament)
                        {
                            Console.WriteLine("Stock insufisant, dispo :" + D);
                            nb_medicament = int.Parse(Console.ReadLine());
                        }
                        D = D - nb_medicament;
                    }
                    if (medicament == "I")
                    {
                        nb_medicament = int.Parse(Console.ReadLine());
                        while (I < nb_medicament)
                        {
                            Console.WriteLine("Stock insufisant, dispo :" + I);
                            nb_medicament = int.Parse(Console.ReadLine());
                        }
                        I = I - nb_medicament;
                    }
                    if (medicament == "E")
                    {
                        nb_medicament = int.Parse(Console.ReadLine());
                        while (E < nb_medicament)
                        {
                            Console.WriteLine("Stock insufisant, dispo :" + E);
                            nb_medicament = int.Parse(Console.ReadLine());
                        }
                        E = E - nb_medicament;
                    }
                    if (medicament == "S")
                    {
                        nb_medicament = int.Parse(Console.ReadLine());
                        while (S < nb_medicament)
                        {
                            Console.WriteLine("Stock insufisant, dispo :" + S);
                            nb_medicament = int.Parse(Console.ReadLine());
                        }
                        S = S - nb_medicament;
                    }
                    Console.WriteLine("Veuillez saisir le prix unitaire du médicament à vendre");
                    prix_medicament = double.Parse(Console.ReadLine());
                    total = prix_medicament * nb_medicament;
                    Console.WriteLine("Ca fera " + nb_medicament + " " + medicament + " à " + prix_medicament + "euros unité. " + "Pour un total de " + total + " Euros");
                }
                /** affichage du stock de médicament ***********************************************/
                if (réponse == "VS")
                {
                    Console.WriteLine("Votre stock de médicament est : ");
                    Console.WriteLine("Doliprane : " + D);
                    Console.WriteLine("Ibuprofene : " + I);
                    Console.WriteLine("Efferalgant : " + E);
                    Console.WriteLine("Spasfon : " + S);
                }
            }
        }
    }
}
