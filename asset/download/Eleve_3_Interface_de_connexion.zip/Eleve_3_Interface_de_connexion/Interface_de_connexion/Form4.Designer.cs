﻿
namespace Interface_de_connexion
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_Matricule = new System.Windows.Forms.TextBox();
            this.tb_Nom = new System.Windows.Forms.TextBox();
            this.tb_Prenom = new System.Windows.Forms.TextBox();
            this.cb_E = new System.Windows.Forms.CheckBox();
            this.cb_I = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_Modifier = new System.Windows.Forms.Button();
            this.btn_Annuler = new System.Windows.Forms.Button();
            this.cbb_Utilisateur = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cb_T = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // tb_Matricule
            // 
            this.tb_Matricule.Location = new System.Drawing.Point(23, 100);
            this.tb_Matricule.Name = "tb_Matricule";
            this.tb_Matricule.Size = new System.Drawing.Size(125, 27);
            this.tb_Matricule.TabIndex = 0;
            this.tb_Matricule.TextChanged += new System.EventHandler(this.tb_Matricule_TextChanged);
            // 
            // tb_Nom
            // 
            this.tb_Nom.Location = new System.Drawing.Point(190, 100);
            this.tb_Nom.Name = "tb_Nom";
            this.tb_Nom.Size = new System.Drawing.Size(125, 27);
            this.tb_Nom.TabIndex = 1;
            this.tb_Nom.TextChanged += new System.EventHandler(this.tb_Nom_TextChanged);
            // 
            // tb_Prenom
            // 
            this.tb_Prenom.Location = new System.Drawing.Point(354, 100);
            this.tb_Prenom.Name = "tb_Prenom";
            this.tb_Prenom.Size = new System.Drawing.Size(125, 27);
            this.tb_Prenom.TabIndex = 2;
            this.tb_Prenom.TextChanged += new System.EventHandler(this.tb_Prenom_TextChanged);
            // 
            // cb_E
            // 
            this.cb_E.AutoSize = true;
            this.cb_E.Location = new System.Drawing.Point(509, 85);
            this.cb_E.Name = "cb_E";
            this.cb_E.Size = new System.Drawing.Size(39, 24);
            this.cb_E.TabIndex = 4;
            this.cb_E.Text = "E";
            this.cb_E.UseVisualStyleBackColor = true;
            // 
            // cb_I
            // 
            this.cb_I.AutoSize = true;
            this.cb_I.Location = new System.Drawing.Point(509, 115);
            this.cb_I.Name = "cb_I";
            this.cb_I.Size = new System.Drawing.Size(35, 24);
            this.cb_I.TabIndex = 5;
            this.cb_I.Text = "I";
            this.cb_I.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Location = new System.Drawing.Point(94, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(324, 50);
            this.label1.TabIndex = 6;
            this.label1.Text = "Modification ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(227, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 20);
            this.label2.TabIndex = 7;
            this.label2.Text = "Nom";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(390, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 20);
            this.label3.TabIndex = 8;
            this.label3.Text = "Prénom";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(52, 73);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Matricule";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("SimSun", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(498, 48);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(152, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Autorisations";
            // 
            // btn_Modifier
            // 
            this.btn_Modifier.BackColor = System.Drawing.Color.Green;
            this.btn_Modifier.Font = new System.Drawing.Font("Arial Nova Cond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_Modifier.Location = new System.Drawing.Point(105, 161);
            this.btn_Modifier.Name = "btn_Modifier";
            this.btn_Modifier.Size = new System.Drawing.Size(122, 46);
            this.btn_Modifier.TabIndex = 11;
            this.btn_Modifier.Text = "Modifier !";
            this.btn_Modifier.UseVisualStyleBackColor = false;
            this.btn_Modifier.Click += new System.EventHandler(this.btn_Modifier_Click);
            // 
            // btn_Annuler
            // 
            this.btn_Annuler.BackColor = System.Drawing.Color.Red;
            this.btn_Annuler.Font = new System.Drawing.Font("Arial Nova Cond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_Annuler.Location = new System.Drawing.Point(296, 161);
            this.btn_Annuler.Name = "btn_Annuler";
            this.btn_Annuler.Size = new System.Drawing.Size(122, 46);
            this.btn_Annuler.TabIndex = 12;
            this.btn_Annuler.Text = "Annuler !";
            this.btn_Annuler.UseVisualStyleBackColor = false;
            this.btn_Annuler.Click += new System.EventHandler(this.btn_Annuler_Click);
            // 
            // cbb_Utilisateur
            // 
            this.cbb_Utilisateur.FormattingEnabled = true;
            this.cbb_Utilisateur.Location = new System.Drawing.Point(602, 100);
            this.cbb_Utilisateur.Name = "cbb_Utilisateur";
            this.cbb_Utilisateur.Size = new System.Drawing.Size(212, 28);
            this.cbb_Utilisateur.TabIndex = 13;
            this.cbb_Utilisateur.SelectedIndexChanged += new System.EventHandler(this.cbb_Utilisateur_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("SimSun", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(639, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(141, 20);
            this.label6.TabIndex = 14;
            this.label6.Text = "Utilisateurs";
            // 
            // cb_T
            // 
            this.cb_T.AutoSize = true;
            this.cb_T.Location = new System.Drawing.Point(509, 146);
            this.cb_T.Name = "cb_T";
            this.cb_T.Size = new System.Drawing.Size(39, 24);
            this.cb_T.TabIndex = 15;
            this.cb_T.Text = "T";
            this.cb_T.UseVisualStyleBackColor = true;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(826, 235);
            this.Controls.Add(this.cb_T);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cbb_Utilisateur);
            this.Controls.Add(this.btn_Annuler);
            this.Controls.Add(this.btn_Modifier);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cb_I);
            this.Controls.Add(this.cb_E);
            this.Controls.Add(this.tb_Prenom);
            this.Controls.Add(this.tb_Nom);
            this.Controls.Add(this.tb_Matricule);
            this.Name = "Form4";
            this.Text = "Form4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_Matricule;
        private System.Windows.Forms.TextBox tb_Nom;
        private System.Windows.Forms.TextBox tb_Prenom;
        private System.Windows.Forms.CheckBox cb_E;
        private System.Windows.Forms.CheckBox cb_I;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_Modifier;
        private System.Windows.Forms.Button btn_Annuler;
        private System.Windows.Forms.ComboBox cbb_Utilisateur;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox cb_T;
    }
}