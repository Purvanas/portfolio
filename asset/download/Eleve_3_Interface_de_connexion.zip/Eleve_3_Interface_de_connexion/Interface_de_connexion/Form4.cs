﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.FileIO;

namespace Interface_de_connexion
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            actualiser();
        }
        // Initialisation des variables
        string line;
        string user = "";
        bool changement = false;
        bool check_matricule = false;
        bool check_nom = false;
        bool check_prenom = false;
        string cbb_MAD = ""; // MAD = Mesure Anti Doublon // sert à n'avoir qu'une seule fois un matricule pour deux autorisations


        private void cbb_Utilisateur_SelectedIndexChanged(object sender, EventArgs e)
        {           
            user = cbb_Utilisateur.Text.Substring(0, 4);
            actualiser();
        }

        private void actualiser()
        {
            // AFFICHAGE DES DONNEES RELATIVE A L'UTILISATEUR SELECTIONNE
            if (user != "")
            {
                tb_Matricule.Text = user; // "user" me permetra d'identifier un profile mais après le changement de son matricule dans la textbox 
                cb_E.Checked = false;// réinitialisation des checkboxs
                cb_I.Checked = false;
                cb_T.Checked = false;
                using (StreamReader sr = new StreamReader("digicod_perso.csv"))
                {

                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] line_splited = line.Split(';');

                        if (line_splited[0] != "Matricule" && line_splited[0] == user)
                        {
                            tb_Nom.Text = line_splited[1];
                            tb_Prenom.Text = line_splited[2];
                            if (line_splited[3] == "E") cb_E.Checked = true;   // Permet de prendre en compte toutes les autorisations
                            if (line_splited[3] == "I") cb_I.Checked = true;
                            if (line_splited[3] == "T") cb_T.Checked = true;

                        }
                    }
                }
            }
            // FIN DE L'AFFICHAGE DES DONNEES RELATIVE A L'UTILISATEUR SELECTIONE

            // ACTUALISATION DE LA CBB
            cbb_Utilisateur.Items.Clear();
            cbb_MAD = "";
            using (StreamReader sr = new StreamReader("digicod_perso.csv"))
            {

                while ((line = sr.ReadLine()) != null)
                {
                    string[] line_splited = line.Split(';');

                    if (line_splited[0] != "Matricule" && cbb_MAD != line_splited[0]) // toujours pour ne pas prendre en compte la deuxième ligne + vérification MAD pour les doublons
                    {
                        cbb_Utilisateur.Items.Add(line_splited[0]+" "+line_splited[1]+" "+ line_splited[2]);
                    }
                    cbb_MAD = line_splited[0];
                }
            }
            // FIN DE L'ACTUALISATION DE LA CBB
        }

        private void btn_Annuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // comme pour suprimer, ici la fonction va copier dans un autre fichier puis le réécrire avec les bons changements dans le fichier initiale
        private void btn_Modifier_Click(object sender, EventArgs e)
        {
            changement = false; // Bool pour savoir quand est fait le changement (c'est important car comme je vais écrire les 2 autorisations en même temps si je ne gère pas le moment du changement je me retrouverais avec 4 lignes au lieu de 2 )
            File.WriteAllText("digicod_perso_changement.csv", ""); // Réinitialisation du fichier de changement
            using (StreamReader sr = new StreamReader("digicod_perso.csv", Encoding.Default))
            {
                while ((line = sr.ReadLine()) != null )
                {
                    string[] line_splited = line.Split(';');
                    if (user != line_splited[0])
                    {
                        File.AppendAllText("digicod_perso_changement.csv", line_splited[0] + ';' + line_splited[1] + ';' + line_splited[2] + ';' + line_splited[3] + "\n");
                    }
                    else if(!changement) // si le changement n'a pas encore été éffectué
                    {
                        if (cb_I.Checked)// écriture d'un profile avec l'autorisation I
                        {
                            File.AppendAllText("digicod_perso_changement.csv", tb_Matricule.Text + ';' + tb_Nom.Text + ';' + tb_Prenom.Text + ';' + "I" + "\n");
                            changement = true;
                        }
                        if (cb_E.Checked)// écriture d'un profile avec l'autorisation E
                        {
                            File.AppendAllText("digicod_perso_changement.csv", tb_Matricule.Text + ';' + tb_Nom.Text + ';' + tb_Prenom.Text + ';' + "E" + "\n");
                            changement = true;
                        }
                        if (cb_T.Checked)// écriture d'un profile avec l'autorisation T
                        {
                            File.AppendAllText("digicod_perso_changement.csv", tb_Matricule.Text + ';' + tb_Nom.Text + ';' + tb_Prenom.Text + ';' + "T" + "\n");
                            changement = true;
                        }

                    }
                }
            }
            File.WriteAllText("digicod_perso.csv", ""); // réinitialisation du fichier digicode_perso.csv
            using (StreamReader sr = new StreamReader("digicod_perso_changement.csv", Encoding.Default))// réecriture du fichier digicode_perso.csv
            {              
                while ((line = sr.ReadLine()) != null)
                {
                    string[] line_splited = line.Split(';');
                    try
                    {
                        File.AppendAllText("digicod_perso.csv", line_splited[0] + ';' + line_splited[1] + ';' + line_splited[2] + ';' + line_splited[3] + "\n");
                    }
                    catch (System.IndexOutOfRangeException)
                    {

                    }
                }
            }
            actualiser();
            this.Close();
        }
        private void tb_check()
        {
            // Vérification du matricule (taille et format) et si il est disponible (c'est un copier coller de la fonction du form 3)
            if (tb_Matricule.Text.Length == 4)
            {
                if (check_matricule)
                {

                }
                check_matricule = true;
                try
                {
                    int.Parse(tb_Matricule.Text);
                }
                catch (System.FormatException)
                {
                    check_matricule = false;
                    MessageBox.Show("Veuillez entrez une suite de 4 chiffres pour le matricule");
                }

            }
            else if (tb_Matricule.Text.Length > 4)
            {
                check_matricule = false;
                MessageBox.Show("Votre matricule doit être composer de 4 chiffres");
            }
            else check_matricule = false;

            // Vérification du nom (taille et majuscule)
            if (tb_Nom.Text.Length > 0)
            {
                if (Majuscule(tb_Nom.Text))
                {
                    check_nom = true;
                    try
                    {
                        tb_Nom.Text.ToString();
                    }
                    catch (System.FormatException)
                    {
                        MessageBox.Show("Veuillez n'entrer que des lettres majuscule");
                        check_nom = false;
                    }
                }
                else
                {
                    MessageBox.Show("Veuillez n'entrer que des lettres majuscules");
                    check_nom = false;
                }
            }
            else check_nom = false;

            // Vérification du prénom (Maj / Min et taille)
            if (tb_Prenom.Text.Length > 0)
            {
                if (Minuscule(tb_Prenom.Text) && char.IsUpper(tb_Prenom.Text[0]))
                {
                    check_prenom = true;
                    try
                    {
                        tb_Prenom.Text.ToString();
                    }
                    catch (System.FormatException)
                    {
                        MessageBox.Show("Veuillez n'entrer qu'une lettre majuscule suivi de lettres minucules");
                        check_prenom = false;
                    }
                }
                else
                {
                    MessageBox.Show("Veuillez n'entrer qu'une lettre majuscule suivi de lettres minucules");
                    check_prenom = false;
                }
            }
            else check_prenom = false;

            // Et enfin Vérification de tout les check précédement fait et dégrisage du bouton ajouter si validés
            if (check_matricule == true && check_nom == true && check_prenom == true) btn_Modifier.Enabled = true;
            else btn_Modifier.Enabled = false;
        }

        bool Majuscule(string input)
        {
            for (int i = 0; i < input.Length; i++)
            {
                if (!Char.IsUpper(input[i]))
                    return false;
            }
            return true;
        }
        bool Minuscule(string input)
        {
            for (int i = 1; i < input.Length; i++)
            {
                if (!Char.IsLower(input[i]))
                    return false;
            }
            return true;
        }

        bool check_Matricule() // verifie si le matricule n'existe pas déjà
        {
            bool e = false;
            bool i = false;
            bool t = false;
            using (StreamReader sr = new StreamReader("digicod_perso.csv"))
            {
                while ((line = sr.ReadLine()) != null)
                {
                    string[] line_splited = line.Split(';');
                    if (line_splited[0] == tb_Matricule.Text)
                    {
                        if (line_splited[3] == "E") e = true;
                        else if (line_splited[3] == "T") t = true;
                        else i = true;
                    }
                }
                if (e && i && t) return true;
                else return false;
            }
        }

        private void tb_Matricule_TextChanged(object sender, EventArgs e)
        {
            tb_check();
        }

        private void tb_Nom_TextChanged(object sender, EventArgs e)
        {
            tb_check();
        }

        private void tb_Prenom_TextChanged(object sender, EventArgs e)
        {
            tb_check();
        }
    }
}
