﻿
namespace Interface_de_connexion
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tb_Matricule = new System.Windows.Forms.TextBox();
            this.tb_Nom = new System.Windows.Forms.TextBox();
            this.tb_Prenom = new System.Windows.Forms.TextBox();
            this.tb_Autorisation = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_Ajouter = new System.Windows.Forms.Button();
            this.btn_Annuler = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tb_Matricule
            // 
            this.tb_Matricule.Location = new System.Drawing.Point(14, 36);
            this.tb_Matricule.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Matricule.Name = "tb_Matricule";
            this.tb_Matricule.Size = new System.Drawing.Size(114, 27);
            this.tb_Matricule.TabIndex = 0;
            this.tb_Matricule.TextChanged += new System.EventHandler(this.tb_Matricule_TextChanged);
            // 
            // tb_Nom
            // 
            this.tb_Nom.Location = new System.Drawing.Point(163, 36);
            this.tb_Nom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Nom.Name = "tb_Nom";
            this.tb_Nom.Size = new System.Drawing.Size(114, 27);
            this.tb_Nom.TabIndex = 1;
            this.tb_Nom.TextChanged += new System.EventHandler(this.tb_Nom_TextChanged);
            // 
            // tb_Prenom
            // 
            this.tb_Prenom.Location = new System.Drawing.Point(311, 36);
            this.tb_Prenom.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Prenom.Name = "tb_Prenom";
            this.tb_Prenom.Size = new System.Drawing.Size(114, 27);
            this.tb_Prenom.TabIndex = 2;
            this.tb_Prenom.TextChanged += new System.EventHandler(this.tb_Prenom_TextChanged);
            // 
            // tb_Autorisation
            // 
            this.tb_Autorisation.Location = new System.Drawing.Point(456, 36);
            this.tb_Autorisation.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Autorisation.Name = "tb_Autorisation";
            this.tb_Autorisation.Size = new System.Drawing.Size(114, 27);
            this.tb_Autorisation.TabIndex = 3;
            this.tb_Autorisation.TextChanged += new System.EventHandler(this.tb_Autorisation_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Matricule";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(200, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Nom";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(337, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Prénom";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(467, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Autorisation";
            // 
            // btn_Ajouter
            // 
            this.btn_Ajouter.BackColor = System.Drawing.Color.Green;
            this.btn_Ajouter.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_Ajouter.Location = new System.Drawing.Point(14, 75);
            this.btn_Ajouter.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Ajouter.Name = "btn_Ajouter";
            this.btn_Ajouter.Size = new System.Drawing.Size(264, 47);
            this.btn_Ajouter.TabIndex = 8;
            this.btn_Ajouter.Text = "Ajouter !";
            this.btn_Ajouter.UseVisualStyleBackColor = false;
            this.btn_Ajouter.Click += new System.EventHandler(this.btn_Ajouter_Click);
            // 
            // btn_Annuler
            // 
            this.btn_Annuler.BackColor = System.Drawing.Color.Red;
            this.btn_Annuler.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_Annuler.Location = new System.Drawing.Point(311, 75);
            this.btn_Annuler.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Annuler.Name = "btn_Annuler";
            this.btn_Annuler.Size = new System.Drawing.Size(259, 47);
            this.btn_Annuler.TabIndex = 9;
            this.btn_Annuler.Text = "Annuler !";
            this.btn_Annuler.UseVisualStyleBackColor = false;
            this.btn_Annuler.Click += new System.EventHandler(this.btn_Annuler_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(594, 141);
            this.Controls.Add(this.btn_Annuler);
            this.Controls.Add(this.btn_Ajouter);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_Autorisation);
            this.Controls.Add(this.tb_Prenom);
            this.Controls.Add(this.tb_Nom);
            this.Controls.Add(this.tb_Matricule);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form3";
            this.Text = "Form3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tb_Matricule;
        private System.Windows.Forms.TextBox tb_Nom;
        private System.Windows.Forms.TextBox tb_Prenom;
        private System.Windows.Forms.TextBox tb_Autorisation;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_Ajouter;
        private System.Windows.Forms.Button btn_Annuler;
    }
}