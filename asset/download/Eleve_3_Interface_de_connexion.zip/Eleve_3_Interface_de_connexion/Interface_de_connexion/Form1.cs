﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.FileIO;



namespace Interface_de_connexion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            tb_Mdp.Enabled = false;
        }

        //Initialisation de variables

        bool autorisation_matricule = false;
        bool autorisation_mdp = false;

        string matricule = "";

        string line;
        string line2;
        string date;
        string annee = DateTime.Now.Year.ToString();







        private void btn_Valider_Click(object sender, EventArgs e)
        { 
            // Verification du matricule en verifiant dans le fichier digicod_perso ligne par ligne jusqu'à tomber sur le matricul selectioné dans la première cellule
            using (StreamReader sr = new StreamReader("digicod_perso.csv", Encoding.Default))
            {
                autorisation_matricule = false;// Booléen qui me permetra de vérifié la validité de l'objet testé
                while ((line = sr.ReadLine()) != null && autorisation_matricule == false) //Lecture ligne par ligne de fichier "digicode_perso.csv"
                {
                    String[] line_splited = line.Split(';');
                    if (line_splited[0] == matricule)
                    {
                        // Puis verification de l'autorisation lié au matricul selectionné
                        if (line_splited[3] == "T") autorisation_matricule = true;                       
                    }                        
                }
                if (autorisation_matricule == false) tb_Cadran.Text = "Entrée non autorisée";                
            }
            // Verification du mot de passe en verifiant dans le fichier digicod_secure ligne par ligne jusqu'à tomber sur l'autorisation "T" 
            using (StreamReader sr2 = new StreamReader("digicod_secure.csv"))
            {           
                autorisation_mdp = false;// Booléen qui me permetra de vérifié la validité de l'objet testé
                while ((line2 = sr2.ReadLine()) != null && autorisation_mdp == false)
                {
                    string[] line_splited2 = line2.Split(';');
                    date = line_splited2[1];
                    string[] date_splited = date.Split('/');// Le split me permetra de récupéré juste l'année
                    if (line_splited2[0] == "T" &&  date_splited[2] == annee)
                    {
                        // Comparaison du mot de passe entré avec celui qui se sittue directement dans le fichier digicod_secure.csv
                        if (tb_Mdp.Text == line_splited2[3]) autorisation_mdp = true; 
                    }
                }
            }
            // Verification de la justesse du mot de passe et du matricule / appel du second form si c'est le cas
            if (autorisation_matricule == true && autorisation_mdp == true)
            {
                tb_Cadran.Text = "Entrée autorisée !";
                interface_Liste_de_diffusion();
            }
            else
            {
                tb_Cadran.Text = "Entrée non autorisée !";
                autorisation_mdp = false;
                autorisation_matricule = false;
            }

        }

        void interface_Liste_de_diffusion() // interface de la liste de diffusion
        {
            Form2 form2 = new Form2();
            form2.Show();    
        }

        // grisage ou non des boutons
        void verif_Bouton() 
        {
            if (tb_Cadran.Text.Length > 5) tb_Cadran.Text = "";
            if (tb_Cadran.Text.Length < 4)
            {
                btn_Num0.Enabled = true;
                btn_Num1.Enabled = true;
                btn_Num2.Enabled = true;
                btn_Num3.Enabled = true;
                btn_Num4.Enabled = true;
                btn_Num5.Enabled = true;
                btn_Num6.Enabled = true;
                btn_Num7.Enabled = true;
                btn_Num8.Enabled = true;
                btn_Num9.Enabled = true;      
                tb_Mdp.Enabled = false;
            }
            else
            {
                btn_Num0.Enabled = false;
                btn_Num1.Enabled = false;
                btn_Num2.Enabled = false;
                btn_Num3.Enabled = false;
                btn_Num4.Enabled = false;
                btn_Num5.Enabled = false;
                btn_Num6.Enabled = false;
                btn_Num7.Enabled = false;
                btn_Num8.Enabled = false;
                btn_Num9.Enabled = false;
                tb_Mdp.Enabled = true;
                tb_Cadran.Text = tb_Cadran.Text + "\r\n" + "\r\n" + "Maintenant entrez votre mot de passe en majuscule";
            }
        }

        
//------ BOUTONS DU DIGICODE  ------
        void btn_Num0_Click(object sender, EventArgs e)
        {
            if (tb_Cadran.Text.Length > 5) tb_Cadran.Text = ""; // pour éffaccer l'écriture de base sur le cadran sans éffacer les étoiles du matricule
            tb_Cadran.Text = tb_Cadran.Text + "*";
            matricule = matricule + "0";
            verif_Bouton();
        }


        void btn_Num1_Click(object sender, EventArgs e)
        {
            if (tb_Cadran.Text.Length > 5) tb_Cadran.Text = "";
            tb_Cadran.Text = tb_Cadran.Text + "*";
            matricule = matricule + "1";
            verif_Bouton();

        }

        void btn_Num2_Click(object sender, EventArgs e)
        {
            if (tb_Cadran.Text.Length > 5) tb_Cadran.Text = "";
            tb_Cadran.Text = tb_Cadran.Text + "*";
            matricule = matricule + "2";
            verif_Bouton();
        }

        void btn_Num3_Click(object sender, EventArgs e)
        {
            if (tb_Cadran.Text.Length > 5) tb_Cadran.Text = "";
            tb_Cadran.Text = tb_Cadran.Text + "*";
            matricule = matricule + "3";
            verif_Bouton();
        }

        void btn_Num4_Click(object sender, EventArgs e)
        {
            if (tb_Cadran.Text.Length > 5) tb_Cadran.Text = "";
            tb_Cadran.Text = tb_Cadran.Text + "*";
            matricule = matricule + "4";
            verif_Bouton();
        }

        void btn_Num5_Click(object sender, EventArgs e)
        {
            if (tb_Cadran.Text.Length > 5) tb_Cadran.Text = "";
            tb_Cadran.Text = tb_Cadran.Text + "*";
            matricule = matricule + "5";
            verif_Bouton();
        }

        void btn_Num6_Click(object sender, EventArgs e)
        {
            if (tb_Cadran.Text.Length > 5) tb_Cadran.Text = "";
            tb_Cadran.Text = tb_Cadran.Text + "*";
            matricule = matricule + "6";
            verif_Bouton();
        }

        void btn_Num7_Click(object sender, EventArgs e)
        {
            if (tb_Cadran.Text.Length > 5) tb_Cadran.Text = "";
            tb_Cadran.Text = tb_Cadran.Text + "*";
            matricule = matricule + "7";
            verif_Bouton();
        }

        void btn_Num8_Click(object sender, EventArgs e)
        {
            if (tb_Cadran.Text.Length > 5) tb_Cadran.Text = "";
            tb_Cadran.Text = tb_Cadran.Text + "*";
            matricule = matricule + "8";
            verif_Bouton();
        }

        void btn_Num9_Click(object sender, EventArgs e)
        {
            if (tb_Cadran.Text.Length > 5) tb_Cadran.Text = "";
            tb_Cadran.Text = tb_Cadran.Text + "*";
            matricule = matricule + "9";
            verif_Bouton();
        }

        void btn_Recomencer_Click(object sender, EventArgs e)
        {
            tb_Cadran.Text = "Veuillez entrer votre matricule s'il vous plait";
            matricule = "";
            tb_Mdp.Enabled = false;
            tb_Mdp.Text = "";
            verif_Bouton();
        }

        //------ FIN DES BOUTONS DU DIGICODE  ------

        private void tb_Mdp_TextChanged(object sender, EventArgs e)
        {
            if (tb_Mdp.Text.Length > 0) btn_Valider.Enabled = true;
            else btn_Valider.Enabled = false; ;
        }
    }
}
