﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.FileIO;

namespace Interface_de_connexion
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            rbtn_E.Checked = true;
            picb_RemoveUser.Enabled = false;
            actualisation_lv();
            
        }

// Initialisation de variables

        string line;
        string matricule;

        bool changement = false;

        

// Fonction qui permet d'actualiser la liste view (et les boutons) pour observer les changements en temps réel (presque il y a quand même unbouton actualiser au cas ou)

        void actualisation_lv()
        {
            lv_ListeDiffusion.Items.Clear();
            cbb_Matricules_Suppr.Items.Clear();

            using (StreamReader sr = new StreamReader("digicod_perso.csv"))
            {

                while ((line = sr.ReadLine()) != null)
                {
                    string[] line_splited = line.Split(';');

                    if(line_splited[0] != "Matricule")// On commence à chercher qu'a parti de la deuxième ligne du csv car la premier ne contien pas de profile mais les indactions des données

                    {
                        if (rbtn_E.Checked == true)
                        {
                            if(line_splited[3]== "E") // séparation des autorisations
                            {
                                ListViewItem ligne = new ListViewItem();

                                ligne.Text = line_splited[0];
                                cbb_Matricules_Suppr.Items.Add(line_splited[0]); //alimentation de la ComboBox
                                ligne.SubItems.Add(line_splited[1]);
                                ligne.SubItems.Add(line_splited[2]);
                                ligne.SubItems.Add(line_splited[3]);
                                lv_ListeDiffusion.Items.Add(ligne);
                            }
                        }
                        else if(rbtn_I.Checked == true)
                        {
                            if (line_splited[3] == "I") // séparation des autorisations
                            {
                                ListViewItem ligne = new ListViewItem();

                                ligne.Text = line_splited[0];
                                cbb_Matricules_Suppr.Items.Add(line_splited[0]); //alimentation de la ComboBox
                                ligne.SubItems.Add(line_splited[1]);
                                ligne.SubItems.Add(line_splited[2]);
                                ligne.SubItems.Add(line_splited[3]);
                                lv_ListeDiffusion.Items.Add(ligne);

                            }
                        }
                        else if (rbtn_T.Checked == true)
                        {
                            if (line_splited[3] == "T") // séparation des autorisations
                            {
                                ListViewItem ligne = new ListViewItem();

                                ligne.Text = line_splited[0];
                                cbb_Matricules_Suppr.Items.Add(line_splited[0]); //alimentation de la ComboBox
                                ligne.SubItems.Add(line_splited[1]);
                                ligne.SubItems.Add(line_splited[2]);
                                ligne.SubItems.Add(line_splited[3]);
                                lv_ListeDiffusion.Items.Add(ligne);

                            }
                        }
                    }
                    
                }
            }
        }

        private void rbtn_E_CheckedChanged(object sender, EventArgs e)
        {
            actualisation_lv();
        }

        private void rbtn_I_CheckedChanged(object sender, EventArgs e)
        {
            actualisation_lv();
        }

        private void rbtn_T_CheckedChanged(object sender, EventArgs e)
        {
             actualisation_lv();
        }
        // PictureBox. Elle va copier le fichier digicod_perso.csv dans digicode_perso_changement.csv pour ensuite réecrire le fichier digicod_perso.csv avec la personne en moins.

        private void picb_RemoveUser_Click(object sender, EventArgs e)
        {
            File.WriteAllText("digicod_perso_changement.csv", "");
            try
            {
                matricule = cbb_Matricules_Suppr.SelectedItem.ToString();
            }
            catch (System.NullReferenceException)
            {
                // Rien on évite juste d'être sorti du programme si on essai de supprimer sans rien avoir selectionné
            }

            changement = false;// Booléen qui me permet de savoir quand le changement a été effectué
            using (StreamReader sr = new StreamReader("digicod_perso.csv",Encoding.Default))
            {
                while ((line = sr.ReadLine()) != null && !changement)
                {
                    string[] line_splited = line.Split(';');
                    if (matricule != line_splited[0])
                    {
                        File.AppendAllText("digicod_perso_changement.csv", line_splited[0] + ';' + line_splited[1] + ';' + line_splited[2] + ';' + line_splited[3] + "\n");
                    }
                    else
                    {
                        if (rbtn_E.Checked && line_splited[3] == "E")
                        {
                            File.AppendAllText("digicod_perso_changement.csv", "\n");
                            changement = true;
                        }
                        else if (rbtn_I.Checked && line_splited[3] == "I")
                        {
                            File.AppendAllText("digicod_perso_changement.csv", "\n");
                            changement = true;
                        }
                        else if (rbtn_T.Checked && line_splited[3] == "T")
                        {
                            File.AppendAllText("digicod_perso_changement.csv", "\n");
                            changement = true;
                        }

                        else File.AppendAllText("digicod_perso_changement.csv", line_splited[0] + ';' + line_splited[1] + ';' + line_splited[2] + ';' + line_splited[3] + "\n");
                    }
                }
            }
            // réécriture du fichier après supression
            using (StreamReader sr = new StreamReader("digicod_perso_changement.csv",Encoding.Default))
            {
                File.WriteAllText("digicod_perso.csv", "");
                while ((line = sr.ReadLine()) != null)
                {
                    string[] line_splited = line.Split(';');
                    try
                    {
                        File.AppendAllText("digicod_perso.csv", line_splited[0] + ';' + line_splited[1] + ';' + line_splited[2] + ';' + line_splited[3] + "\n");
                    }                  
                    catch(System.IndexOutOfRangeException)
                    {

                    }
                }
            }
            cbb_Matricules_Suppr.Text="";
            actualisation_lv();
        }

        private void picb_AddUser_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
        }

        private void btn_Actualiser_Click(object sender, EventArgs e)
        {
            actualisation_lv();
        }

        private void cbb_Matricules_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbb_Matricules_Suppr.SelectedItem.ToString().Length > 0) picb_RemoveUser.Enabled = true;
            else picb_RemoveUser.Enabled = false;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
        }
    }
}
