﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.FileIO;

namespace Interface_de_connexion
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            btn_Ajouter.Enabled = false;
        }
        // Initialisation des variables
        bool check_matricule = false;
        bool check_nom = false;
        bool check_prenom = false;
        bool check_autorisation = false;
        string line;

        // Ferme la fenêtre
        private void btn_Annuler_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Ajouter_Click(object sender, EventArgs e)
        {
            if (check_Matricule()) MessageBox.Show("Le matricule est déjà utilisé");
            else
            {
                File.AppendAllText("digicod_perso.csv", tb_Matricule.Text + ';' + tb_Nom.Text + ';' + tb_Prenom.Text + ';' + tb_Autorisation.Text + "\n");
                this.Close();
            }
            
        }

        private void tb_check()
        {
            // Vérification du matricule (taille et format) et si il est disponible
            if (tb_Matricule.Text.Length == 4)
            {
                if (check_matricule)
                {

                }
                check_matricule = true;
                try
                {
                    int.Parse(tb_Matricule.Text);
                }
                catch (System.FormatException)
                {
                    check_matricule = false;
                    MessageBox.Show("Veuillez entrez une suite de 4 chiffres pour le matricule");                   
                }
                
            }
            else check_matricule = false;

            // Vérification du nom (taille et majuscule)
            if (tb_Nom.Text.Length > 0)
            {
                if (Majuscule(tb_Nom.Text))
                {
                    check_nom = true;
                    try
                    {
                        tb_Nom.Text.ToString();
                    }
                    catch (System.FormatException)
                    {
                        MessageBox.Show("Veuillez n'entrer que des lettres majuscule");
                        check_nom = false;
                    }
                }
                else
                {
                    MessageBox.Show("Veuillez n'entrer que des lettres majuscules");
                    check_nom = false;
                }
            }
            else check_nom = false;

            // Vérification du prénom (Maj / Min et taille)
            if (tb_Prenom.Text.Length > 0)
            {
                if (Minuscule(tb_Prenom.Text) && char.IsUpper(tb_Prenom.Text[0]))
                {
                    check_prenom = true;
                    try
                    {
                        tb_Prenom.Text.ToString();
                    }
                    catch (System.FormatException)
                    {
                        MessageBox.Show("Veuillez n'entrer qu'une lettre majuscule suivi de lettres minucules");
                        check_prenom = false;
                    }
                }
                else
                {
                    MessageBox.Show("Veuillez n'entrer qu'une lettre majuscule suivi de lettres minucules");
                    check_prenom = false;
                }
            }
            else check_prenom = false;

            // Vérification de l'autorisation (I, E ou T uniquement)
            if (tb_Autorisation.Text == "E" || tb_Autorisation.Text == "I" || tb_Autorisation.Text == "T") check_autorisation = true;
            else if (tb_Autorisation.Text.Length > 0)
            {
                check_autorisation = false;
                MessageBox.Show("Veuillez E, I ou T en fonction de l'autorisation à accorder");
            }
            else check_autorisation = false;

            // Et enfin Vérification de tout les check précédement fait et dégrisage du bouton ajouter si validés
            if (check_autorisation == true && check_matricule == true && check_nom == true && check_prenom == true) btn_Ajouter.Enabled = true;
            else btn_Ajouter.Enabled = false;                  
        }

        //Fonction qui me permet de savoir si l'objet selectioné est une majuscule
        bool Majuscule(string input)
        {
            for (int i = 0; i < input.Length; i++)
            {
                if (!Char.IsUpper(input[i]))
                    return false;
            }
            return true;
        }

        //Fonction qui me permet de savoir si l'objet selectioné est une minuscule
        bool Minuscule(string input)
        {
            for (int i = 1; i < input.Length; i++)
            {
                if (!Char.IsLower(input[i]))
                    return false;
            }
            return true;
        }

        bool check_Matricule() // verifie si le matricule n'existe pas déjà
        {
            bool e = false;
            bool i = false;
            bool t = false;
            using (StreamReader sr = new StreamReader("digicod_perso.csv"))
            {
                while ((line = sr.ReadLine()) != null)
                {
                    string[] line_splited = line.Split(';');
                    if (line_splited[0]== tb_Matricule.Text)
                    {
                        if (line_splited[3] == "E") e = true;
                        else if (line_splited[3] == "T") t = true;
                        else i = true;
                    }
                }
                if (e && i && t) return true;
                else return false;
            }
        }

        private void tb_Matricule_TextChanged(object sender, EventArgs e)
        {
            tb_check();
        }

        private void tb_Nom_TextChanged(object sender, EventArgs e)
        {
            tb_check();
        }

        private void tb_Prenom_TextChanged(object sender, EventArgs e)
        {
            tb_check();
        }

        private void tb_Autorisation_TextChanged(object sender, EventArgs e)
        {
            tb_check();
        }
    }
}
