﻿
namespace Interface_de_connexion
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Num7 = new System.Windows.Forms.Button();
            this.btn_Num8 = new System.Windows.Forms.Button();
            this.btn_Num9 = new System.Windows.Forms.Button();
            this.btn_Num4 = new System.Windows.Forms.Button();
            this.btn_Num5 = new System.Windows.Forms.Button();
            this.btn_Num6 = new System.Windows.Forms.Button();
            this.btn_Num1 = new System.Windows.Forms.Button();
            this.btn_Num2 = new System.Windows.Forms.Button();
            this.btn_Num3 = new System.Windows.Forms.Button();
            this.tb_Cadran = new System.Windows.Forms.TextBox();
            this.btn_Num0 = new System.Windows.Forms.Button();
            this.tb_Mdp = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_Valider = new System.Windows.Forms.Button();
            this.btn_Recomencer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_Num7
            // 
            this.btn_Num7.Location = new System.Drawing.Point(51, 187);
            this.btn_Num7.Name = "btn_Num7";
            this.btn_Num7.Size = new System.Drawing.Size(80, 80);
            this.btn_Num7.TabIndex = 0;
            this.btn_Num7.Text = "7";
            this.btn_Num7.UseVisualStyleBackColor = true;
            this.btn_Num7.Click += new System.EventHandler(this.btn_Num7_Click);
            // 
            // btn_Num8
            // 
            this.btn_Num8.Location = new System.Drawing.Point(171, 187);
            this.btn_Num8.Name = "btn_Num8";
            this.btn_Num8.Size = new System.Drawing.Size(80, 80);
            this.btn_Num8.TabIndex = 1;
            this.btn_Num8.Text = "8";
            this.btn_Num8.UseVisualStyleBackColor = true;
            this.btn_Num8.Click += new System.EventHandler(this.btn_Num8_Click);
            // 
            // btn_Num9
            // 
            this.btn_Num9.Location = new System.Drawing.Point(286, 187);
            this.btn_Num9.Name = "btn_Num9";
            this.btn_Num9.Size = new System.Drawing.Size(80, 80);
            this.btn_Num9.TabIndex = 2;
            this.btn_Num9.Text = "9";
            this.btn_Num9.UseVisualStyleBackColor = true;
            this.btn_Num9.Click += new System.EventHandler(this.btn_Num9_Click);
            // 
            // btn_Num4
            // 
            this.btn_Num4.Location = new System.Drawing.Point(51, 291);
            this.btn_Num4.Name = "btn_Num4";
            this.btn_Num4.Size = new System.Drawing.Size(80, 80);
            this.btn_Num4.TabIndex = 3;
            this.btn_Num4.Text = "4";
            this.btn_Num4.UseVisualStyleBackColor = true;
            this.btn_Num4.Click += new System.EventHandler(this.btn_Num4_Click);
            // 
            // btn_Num5
            // 
            this.btn_Num5.Location = new System.Drawing.Point(171, 291);
            this.btn_Num5.Name = "btn_Num5";
            this.btn_Num5.Size = new System.Drawing.Size(80, 80);
            this.btn_Num5.TabIndex = 4;
            this.btn_Num5.Text = "5";
            this.btn_Num5.UseVisualStyleBackColor = true;
            this.btn_Num5.Click += new System.EventHandler(this.btn_Num5_Click);
            // 
            // btn_Num6
            // 
            this.btn_Num6.Location = new System.Drawing.Point(286, 291);
            this.btn_Num6.Name = "btn_Num6";
            this.btn_Num6.Size = new System.Drawing.Size(80, 80);
            this.btn_Num6.TabIndex = 5;
            this.btn_Num6.Text = "6";
            this.btn_Num6.UseVisualStyleBackColor = true;
            this.btn_Num6.Click += new System.EventHandler(this.btn_Num6_Click);
            // 
            // btn_Num1
            // 
            this.btn_Num1.Location = new System.Drawing.Point(51, 395);
            this.btn_Num1.Name = "btn_Num1";
            this.btn_Num1.Size = new System.Drawing.Size(80, 80);
            this.btn_Num1.TabIndex = 6;
            this.btn_Num1.Text = "1";
            this.btn_Num1.UseVisualStyleBackColor = true;
            this.btn_Num1.Click += new System.EventHandler(this.btn_Num1_Click);
            // 
            // btn_Num2
            // 
            this.btn_Num2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btn_Num2.Location = new System.Drawing.Point(171, 395);
            this.btn_Num2.Name = "btn_Num2";
            this.btn_Num2.Size = new System.Drawing.Size(80, 80);
            this.btn_Num2.TabIndex = 7;
            this.btn_Num2.Text = "2";
            this.btn_Num2.UseVisualStyleBackColor = false;
            this.btn_Num2.Click += new System.EventHandler(this.btn_Num2_Click);
            // 
            // btn_Num3
            // 
            this.btn_Num3.Location = new System.Drawing.Point(286, 395);
            this.btn_Num3.Name = "btn_Num3";
            this.btn_Num3.Size = new System.Drawing.Size(80, 80);
            this.btn_Num3.TabIndex = 8;
            this.btn_Num3.Text = "3";
            this.btn_Num3.UseVisualStyleBackColor = true;
            this.btn_Num3.Click += new System.EventHandler(this.btn_Num3_Click);
            // 
            // tb_Cadran
            // 
            this.tb_Cadran.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.tb_Cadran.ForeColor = System.Drawing.SystemColors.Window;
            this.tb_Cadran.Location = new System.Drawing.Point(51, 12);
            this.tb_Cadran.Multiline = true;
            this.tb_Cadran.Name = "tb_Cadran";
            this.tb_Cadran.ReadOnly = true;
            this.tb_Cadran.Size = new System.Drawing.Size(315, 129);
            this.tb_Cadran.TabIndex = 9;
            this.tb_Cadran.Text = "Veuillez entrer votre matricule s\'il vous plait";
            // 
            // btn_Num0
            // 
            this.btn_Num0.Location = new System.Drawing.Point(123, 480);
            this.btn_Num0.Name = "btn_Num0";
            this.btn_Num0.Size = new System.Drawing.Size(173, 57);
            this.btn_Num0.TabIndex = 10;
            this.btn_Num0.Text = "0";
            this.btn_Num0.UseVisualStyleBackColor = true;
            this.btn_Num0.Click += new System.EventHandler(this.btn_Num0_Click);
            // 
            // tb_Mdp
            // 
            this.tb_Mdp.Location = new System.Drawing.Point(51, 572);
            this.tb_Mdp.Name = "tb_Mdp";
            this.tb_Mdp.PasswordChar = '*';
            this.tb_Mdp.Size = new System.Drawing.Size(315, 27);
            this.tb_Mdp.TabIndex = 11;
            this.tb_Mdp.TextChanged += new System.EventHandler(this.tb_Mdp_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(165, 153);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 20);
            this.label1.TabIndex = 12;
            this.label1.Text = "MATRICULE";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(152, 540);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 20);
            this.label2.TabIndex = 13;
            this.label2.Text = "MOT DE PASSE";
            // 
            // btn_Valider
            // 
            this.btn_Valider.Enabled = false;
            this.btn_Valider.Font = new System.Drawing.Font("Arial Nova Cond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_Valider.Location = new System.Drawing.Point(34, 620);
            this.btn_Valider.Name = "btn_Valider";
            this.btn_Valider.Size = new System.Drawing.Size(200, 33);
            this.btn_Valider.TabIndex = 14;
            this.btn_Valider.Text = "Valider !";
            this.btn_Valider.UseVisualStyleBackColor = true;
            this.btn_Valider.Click += new System.EventHandler(this.btn_Valider_Click);
            // 
            // btn_Recomencer
            // 
            this.btn_Recomencer.Font = new System.Drawing.Font("Arial Nova Cond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_Recomencer.Location = new System.Drawing.Point(258, 620);
            this.btn_Recomencer.Name = "btn_Recomencer";
            this.btn_Recomencer.Size = new System.Drawing.Size(138, 33);
            this.btn_Recomencer.TabIndex = 15;
            this.btn_Recomencer.Text = "Recomencer !";
            this.btn_Recomencer.UseVisualStyleBackColor = true;
            this.btn_Recomencer.Click += new System.EventHandler(this.btn_Recomencer_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGray;
            this.ClientSize = new System.Drawing.Size(421, 681);
            this.Controls.Add(this.btn_Recomencer);
            this.Controls.Add(this.btn_Valider);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_Mdp);
            this.Controls.Add(this.btn_Num0);
            this.Controls.Add(this.tb_Cadran);
            this.Controls.Add(this.btn_Num3);
            this.Controls.Add(this.btn_Num2);
            this.Controls.Add(this.btn_Num1);
            this.Controls.Add(this.btn_Num6);
            this.Controls.Add(this.btn_Num5);
            this.Controls.Add(this.btn_Num4);
            this.Controls.Add(this.btn_Num9);
            this.Controls.Add(this.btn_Num8);
            this.Controls.Add(this.btn_Num7);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Num7;
        private System.Windows.Forms.Button btn_Num8;
        private System.Windows.Forms.Button btn_Num9;
        private System.Windows.Forms.Button btn_Num4;
        private System.Windows.Forms.Button btn_Num5;
        private System.Windows.Forms.Button btn_Num6;
        private System.Windows.Forms.Button btn_Num1;
        private System.Windows.Forms.Button btn_Num2;
        private System.Windows.Forms.Button btn_Num3;
        private System.Windows.Forms.TextBox tb_Cadran;
        private System.Windows.Forms.Button btn_Num0;
        private System.Windows.Forms.TextBox tb_Mdp;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_Valider;
        private System.Windows.Forms.Button btn_Recomencer;
    }
}

