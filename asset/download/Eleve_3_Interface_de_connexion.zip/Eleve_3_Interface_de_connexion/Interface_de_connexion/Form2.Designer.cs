﻿
namespace Interface_de_connexion
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.label1 = new System.Windows.Forms.Label();
            this.lv_ListeDiffusion = new System.Windows.Forms.ListView();
            this.Matricule = new System.Windows.Forms.ColumnHeader();
            this.Nom = new System.Windows.Forms.ColumnHeader();
            this.Prénom = new System.Windows.Forms.ColumnHeader();
            this.Autorisation = new System.Windows.Forms.ColumnHeader();
            this.label2 = new System.Windows.Forms.Label();
            this.rbtn_E = new System.Windows.Forms.RadioButton();
            this.rbtn_I = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.picb_AddUser = new System.Windows.Forms.PictureBox();
            this.picb_RemoveUser = new System.Windows.Forms.PictureBox();
            this.btn_Actualiser = new System.Windows.Forms.Button();
            this.cbb_Matricules_Suppr = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.rbtn_T = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.picb_AddUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_RemoveUser)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 31);
            this.label1.TabIndex = 0;
            // 
            // lv_ListeDiffusion
            // 
            this.lv_ListeDiffusion.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.lv_ListeDiffusion.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Matricule,
            this.Nom,
            this.Prénom,
            this.Autorisation});
            this.lv_ListeDiffusion.HideSelection = false;
            this.lv_ListeDiffusion.Location = new System.Drawing.Point(14, 63);
            this.lv_ListeDiffusion.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.lv_ListeDiffusion.Name = "lv_ListeDiffusion";
            this.lv_ListeDiffusion.Size = new System.Drawing.Size(564, 480);
            this.lv_ListeDiffusion.TabIndex = 1;
            this.lv_ListeDiffusion.UseCompatibleStateImageBehavior = false;
            this.lv_ListeDiffusion.View = System.Windows.Forms.View.Details;
            // 
            // Matricule
            // 
            this.Matricule.Text = "Matricule";
            this.Matricule.Width = 100;
            // 
            // Nom
            // 
            this.Nom.Text = "Nom";
            this.Nom.Width = 150;
            // 
            // Prénom
            // 
            this.Prénom.Text = "Prénom";
            this.Prénom.Width = 150;
            // 
            // Autorisation
            // 
            this.Autorisation.Text = "Autorisation";
            this.Autorisation.Width = 100;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Showcard Gothic", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(138, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(230, 29);
            this.label2.TabIndex = 2;
            this.label2.Text = "Liste de diffusion";
            // 
            // rbtn_E
            // 
            this.rbtn_E.AutoSize = true;
            this.rbtn_E.Location = new System.Drawing.Point(610, 63);
            this.rbtn_E.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtn_E.Name = "rbtn_E";
            this.rbtn_E.Size = new System.Drawing.Size(38, 24);
            this.rbtn_E.TabIndex = 3;
            this.rbtn_E.TabStop = true;
            this.rbtn_E.Text = "E";
            this.rbtn_E.UseVisualStyleBackColor = true;
            this.rbtn_E.CheckedChanged += new System.EventHandler(this.rbtn_E_CheckedChanged);
            // 
            // rbtn_I
            // 
            this.rbtn_I.AutoSize = true;
            this.rbtn_I.Location = new System.Drawing.Point(654, 63);
            this.rbtn_I.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rbtn_I.Name = "rbtn_I";
            this.rbtn_I.Size = new System.Drawing.Size(34, 24);
            this.rbtn_I.TabIndex = 4;
            this.rbtn_I.TabStop = true;
            this.rbtn_I.Text = "I";
            this.rbtn_I.UseVisualStyleBackColor = true;
            this.rbtn_I.CheckedChanged += new System.EventHandler(this.rbtn_I_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("NSimSun", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(584, 39);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(163, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Autorisations ";
            // 
            // picb_AddUser
            // 
            this.picb_AddUser.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picb_AddUser.Image = ((System.Drawing.Image)(resources.GetObject("picb_AddUser.Image")));
            this.picb_AddUser.Location = new System.Drawing.Point(607, 108);
            this.picb_AddUser.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.picb_AddUser.Name = "picb_AddUser";
            this.picb_AddUser.Size = new System.Drawing.Size(102, 117);
            this.picb_AddUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picb_AddUser.TabIndex = 6;
            this.picb_AddUser.TabStop = false;
            this.picb_AddUser.Click += new System.EventHandler(this.picb_AddUser_Click);
            // 
            // picb_RemoveUser
            // 
            this.picb_RemoveUser.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picb_RemoveUser.Image = ((System.Drawing.Image)(resources.GetObject("picb_RemoveUser.Image")));
            this.picb_RemoveUser.Location = new System.Drawing.Point(607, 249);
            this.picb_RemoveUser.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.picb_RemoveUser.Name = "picb_RemoveUser";
            this.picb_RemoveUser.Size = new System.Drawing.Size(102, 117);
            this.picb_RemoveUser.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picb_RemoveUser.TabIndex = 7;
            this.picb_RemoveUser.TabStop = false;
            this.picb_RemoveUser.Click += new System.EventHandler(this.picb_RemoveUser_Click);
            // 
            // btn_Actualiser
            // 
            this.btn_Actualiser.BackColor = System.Drawing.Color.Beige;
            this.btn_Actualiser.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Actualiser.Font = new System.Drawing.Font("Arial Nova Cond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btn_Actualiser.Location = new System.Drawing.Point(76, 564);
            this.btn_Actualiser.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_Actualiser.Name = "btn_Actualiser";
            this.btn_Actualiser.Size = new System.Drawing.Size(170, 57);
            this.btn_Actualiser.TabIndex = 8;
            this.btn_Actualiser.Text = "Actualiser";
            this.btn_Actualiser.UseVisualStyleBackColor = false;
            this.btn_Actualiser.Click += new System.EventHandler(this.btn_Actualiser_Click);
            // 
            // cbb_Matricules_Suppr
            // 
            this.cbb_Matricules_Suppr.FormattingEnabled = true;
            this.cbb_Matricules_Suppr.Location = new System.Drawing.Point(724, 277);
            this.cbb_Matricules_Suppr.Name = "cbb_Matricules_Suppr";
            this.cbb_Matricules_Suppr.Size = new System.Drawing.Size(155, 28);
            this.cbb_Matricules_Suppr.TabIndex = 9;
            this.cbb_Matricules_Suppr.SelectedIndexChanged += new System.EventHandler(this.cbb_Matricules_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Nova Cond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label4.Location = new System.Drawing.Point(751, 108);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 25);
            this.label4.TabIndex = 10;
            this.label4.Text = "Ajouter !";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Nova Cond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(749, 249);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 25);
            this.label5.TabIndex = 11;
            this.label5.Text = "Supprimer !";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(607, 392);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 117);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial Nova Cond", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.Location = new System.Drawing.Point(751, 439);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 25);
            this.label6.TabIndex = 13;
            this.label6.Text = "Modifier !";
            // 
            // rbtn_T
            // 
            this.rbtn_T.AutoSize = true;
            this.rbtn_T.Location = new System.Drawing.Point(694, 63);
            this.rbtn_T.Name = "rbtn_T";
            this.rbtn_T.Size = new System.Drawing.Size(38, 24);
            this.rbtn_T.TabIndex = 14;
            this.rbtn_T.TabStop = true;
            this.rbtn_T.Text = "T";
            this.rbtn_T.UseVisualStyleBackColor = true;
            this.rbtn_T.CheckedChanged += new System.EventHandler(this.rbtn_T_CheckedChanged);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(969, 645);
            this.Controls.Add(this.rbtn_T);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cbb_Matricules_Suppr);
            this.Controls.Add(this.btn_Actualiser);
            this.Controls.Add(this.picb_RemoveUser);
            this.Controls.Add(this.picb_AddUser);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.rbtn_I);
            this.Controls.Add(this.rbtn_E);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lv_ListeDiffusion);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.picb_AddUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picb_RemoveUser)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView lv_ListeDiffusion;
        private System.Windows.Forms.ColumnHeader Matricule;
        private System.Windows.Forms.ColumnHeader Nom;
        private System.Windows.Forms.ColumnHeader Prénom;
        private System.Windows.Forms.ColumnHeader Autorisation;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rbtn_E;
        private System.Windows.Forms.RadioButton rbtn_I;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox picb_AddUser;
        private System.Windows.Forms.PictureBox picb_RemoveUser;
        private System.Windows.Forms.Button btn_Actualiser;
        private System.Windows.Forms.ComboBox cbb_Matricules_Suppr;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton rbtn_T;
    }
}